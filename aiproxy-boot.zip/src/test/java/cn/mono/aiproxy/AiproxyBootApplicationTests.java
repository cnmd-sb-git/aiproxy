package cn.mono.aiproxy;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AiproxyBootApplicationTests {

	@Test
	void contextLoads() {
	}

}
